#!/bin/bash
echo "=== SuperAdmin Portainer Fix ==="

BACKEND_CONTAINER=$(docker ps --format '{{.Names}}' | grep -E "superadmin.*backend|backend.*superadmin" | head -1)

if [ -z "$BACKEND_CONTAINER" ]; then
    echo "ERROR: Backend container not found!"
    docker ps --format '{{.Names}}'
    exit 1
fi

echo "Backend container: $BACKEND_CONTAINER"
echo "Updating..."

docker cp backend/server.py $BACKEND_CONTAINER:/app/
docker cp backend/services $BACKEND_CONTAINER:/app/

echo "Restarting backend..."
docker restart $BACKEND_CONTAINER

echo ""
echo "=== Done! Portainer URL: https://72.61.158.147:9443 ==="
