window.__RUNTIME_CONFIG__ = {
  API_URL: ""  // Bu her firma için değiştirilecek
};
