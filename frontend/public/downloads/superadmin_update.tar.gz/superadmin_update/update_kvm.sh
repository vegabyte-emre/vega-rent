#!/bin/bash
echo "=== SuperAdmin KVM Update Script ==="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root (sudo)"
    exit 1
fi

# Detect containers
BACKEND_CONTAINER=$(docker ps --format '{{.Names}}' | grep -E "superadmin.*backend|backend.*superadmin" | head -1)
FRONTEND_CONTAINER=$(docker ps --format '{{.Names}}' | grep -E "superadmin.*frontend|frontend.*superadmin" | head -1)

echo "Detected containers:"
echo "  Backend: ${BACKEND_CONTAINER:-NOT FOUND}"
echo "  Frontend: ${FRONTEND_CONTAINER:-NOT FOUND}"
echo ""

if [ -z "$BACKEND_CONTAINER" ] || [ -z "$FRONTEND_CONTAINER" ]; then
    echo "ERROR: Could not detect SuperAdmin containers!"
    echo "Available containers:"
    docker ps --format '{{.Names}}'
    exit 1
fi

# Backup current files
echo "Creating backups..."
BACKUP_DIR="/root/superadmin_backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p $BACKUP_DIR
docker cp $BACKEND_CONTAINER:/app/server.py $BACKUP_DIR/ 2>/dev/null
docker cp $BACKEND_CONTAINER:/app/services $BACKUP_DIR/ 2>/dev/null
echo "Backup saved to: $BACKUP_DIR"

# Update backend
echo ""
echo "Updating backend..."
docker cp backend/server.py $BACKEND_CONTAINER:/app/
docker cp backend/services $BACKEND_CONTAINER:/app/
docker exec $BACKEND_CONTAINER pip install -r /app/requirements.txt --quiet 2>/dev/null

# Update frontend
echo "Updating frontend..."
docker cp frontend/. $FRONTEND_CONTAINER:/usr/share/nginx/html/

# Restart containers
echo ""
echo "Restarting containers..."
docker restart $BACKEND_CONTAINER
sleep 3
docker restart $FRONTEND_CONTAINER

echo ""
echo "=== Update Complete ==="
echo "Backend URL: http://$(hostname -I | awk '{print $1}'):9001"
echo "Frontend URL: http://$(hostname -I | awk '{print $1}'):9000"
